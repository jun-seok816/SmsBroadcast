
function clickBtn(){

var tv_content;
var tv_sender;


var e = document.getElementById('aa');
       var c=AndroidDevice.ShowSMS2();
       e.innerHTML=c;
    AndroidDevice.ShowSMS2 ();


}
function ShowSMS3(){
}

